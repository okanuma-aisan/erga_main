# autoware_launch

A launch configuration repository for [Autoware](https://github.com/autowarefoundation/autoware), containing node configurations and their parameters.
